﻿using PracticeProject.Models;

namespace PracticeProject.Services
{
    public class DetailsEntityViewModel : EntityViewModel
    {
        public string Id { get; set; }
    }
}
