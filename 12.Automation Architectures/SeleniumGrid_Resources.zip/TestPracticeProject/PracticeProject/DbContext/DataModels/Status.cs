﻿namespace PracticeProject.DbContext.DataModels
{
    public enum Status
    {
        One = 10,
        Two = 20,
        Three = 30,
        Four = 40
    }
}
